import unittest
from unittest.mock import MagicMock, patch
from fastapi.testclient import TestClient

# Mock database at import time to prevent network attempts
with patch("database.get_table") as mock_get_table:
    from main import app
    client = TestClient(app)


class TestCartService(unittest.TestCase):
    def test_health(self):
        response = client.get("/")
        self.assertEqual(response.status_code, 200)
        self.assertEqual(response.json(), {"service": "cart-service", "status": "ok"})

    @patch("service.get_table")
    @patch("service._validate_product")
    def test_add_to_cart_success(self, mock_validate_product, mock_get_table):
        mock_validate_product.return_value = None
        mock_table = MagicMock()
        mock_get_table.return_value = mock_table

        token = "dXNlcjEyMzoxNzIwMDAwMDAw" # user123:timestamp
        response = client.post(
            "/v1/cart",
            headers={"Authorization": f"Bearer {token}"},
            json={"user_id": "user123", "product_id": "prod-1", "quantity": 2, "price": 49.99}
        )
        self.assertEqual(response.status_code, 201)
        self.assertIn("cart_id", response.json())
        self.assertEqual(response.json()["message"], "Added To Cart")

    @patch("service.get_table")
    def test_get_cart_items(self, mock_get_table):
        mock_table = MagicMock()
        mock_table.scan.return_value = {
            "Items": [{"cart_id": "c-1", "user_id": "user123", "product_id": "prod-1", "quantity": 2, "price": 49.99}]
        }
        mock_get_table.return_value = mock_table

        token = "dXNlcjEyMzoxNzIwMDAwMDAw"
        response = client.get(
            "/v1/cart/user123",
            headers={"Authorization": f"Bearer {token}"}
        )
        self.assertEqual(response.status_code, 200)
        self.assertEqual(len(response.json()), 1)
        self.assertEqual(response.json()[0]["product_id"], "prod-1")


if __name__ == "__main__":
    unittest.main()
