import unittest
from unittest.mock import MagicMock, patch
from fastapi.testclient import TestClient

# Mock database at import time to prevent network attempts
with patch("database.get_table") as mock_get_table:
    from main import app
    client = TestClient(app)


class TestOrderService(unittest.TestCase):
    def test_health(self):
        response = client.get("/")
        self.assertEqual(response.status_code, 200)
        self.assertEqual(response.json(), {"service": "order-service", "status": "ok"})

    @patch("service.get_table")
    @patch("service.sns")
    @patch("service.httpx")
    def test_create_order(self, mock_httpx, mock_sns, mock_get_table):
        mock_table = MagicMock()
        mock_get_table.return_value = mock_table
        
        token = "dXNlcjEyMzoxNzIwMDAwMDAw"
        response = client.post(
            "/v1/orders",
            headers={"Authorization": f"Bearer {token}"},
            json={
                "user_id": "user123",
                "product_id": "prod-1",
                "quantity": 2,
                "amount": 99.98,
                "size": "M",
                "shipping_name": "Jane",
                "shipping_address": "Singapore"
            }
        )
        self.assertEqual(response.status_code, 201)
        self.assertIn("order_id", response.json())
        self.assertEqual(response.json()["message"], "Order Created")

    @patch("service.get_table")
    def test_get_order_by_id(self, mock_get_table):
        mock_table = MagicMock()
        mock_table.get_item.return_value = {
            "Item": {"order_id": "o-1", "user_id": "user123", "product_id": "prod-1", "quantity": 1, "amount": 49.99}
        }
        mock_get_table.return_value = mock_table

        token = "dXNlcjEyMzoxNzIwMDAwMDAw"
        response = client.get(
            "/v1/orders/o-1",
            headers={"Authorization": f"Bearer {token}"}
        )
        self.assertEqual(response.status_code, 200)
        self.assertEqual(response.json()["order_id"], "o-1")


if __name__ == "__main__":
    unittest.main()
