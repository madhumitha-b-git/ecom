import unittest
from unittest.mock import MagicMock, patch
from fastapi.testclient import TestClient

# Mock database at import time to prevent network attempts
with patch("database.get_table") as mock_get_table:
    from main import app
    client = TestClient(app)


class TestInventoryService(unittest.TestCase):
    def test_health(self):
        response = client.get("/")
        self.assertEqual(response.status_code, 200)
        self.assertEqual(response.json(), {"service": "inventory-service", "status": "ok"})

    @patch("service.get_table")
    @patch("service._get_product")
    def test_add_inventory_success(self, mock_get_product, mock_get_table):
        mock_get_product.return_value = {"product_id": "prod-1", "name": "Shirt", "price": 19.99}
        mock_table = MagicMock()
        mock_get_table.return_value = mock_table

        token = "dXNlcjEyMzoxNzIwMDAwMDAw"
        response = client.post(
            "/v1/inventory",
            headers={"Authorization": f"Bearer {token}"},
            json={"product_id": "prod-1", "stock": 100}
        )
        self.assertEqual(response.status_code, 201)
        self.assertEqual(response.json()["product_id"], "prod-1")

    @patch("service.get_table")
    @patch("service._get_product")
    def test_get_stock_level(self, mock_get_product, mock_get_table):
        mock_get_product.return_value = {"product_id": "prod-1", "name": "Shirt", "price": 19.99}
        mock_table = MagicMock()
        mock_table.get_item.return_value = {
            "Item": {"product_id": "prod-1", "stock": 50}
        }
        mock_get_table.return_value = mock_table

        token = "dXNlcjEyMzoxNzIwMDAwMDAw"
        response = client.get(
            "/v1/inventory/prod-1",
            headers={"Authorization": f"Bearer {token}"}
        )
        self.assertEqual(response.status_code, 200)
        self.assertEqual(response.json()["stock"], 50)


if __name__ == "__main__":
    unittest.main()
