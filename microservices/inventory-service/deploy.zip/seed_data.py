import httpx
import boto3
from botocore.exceptions import ClientError

AWS_REGION = "ap-southeast-1"
AWS_PROFILE = "idp-sbx-trn-lab-01"
PRODUCT_SERVICE_URL = "http://localhost:8004"
INVENTORY_SERVICE_URL = "http://localhost:8002"

session = boto3.Session(profile_name=AWS_PROFILE)
dynamodb = session.resource("dynamodb", region_name=AWS_REGION)

products_table = dynamodb.Table("Products_ecom")
inventory_table = dynamodb.Table("inventory_ecom")


def delete_all_items(table, primary_key):
    scan = table.scan()
    with table.batch_writer() as batch:
        for item in scan.get("Items", []):
            batch.delete_item(Key={primary_key: item[primary_key]})
    while "LastEvaluatedKey" in scan:
        scan = table.scan(ExclusiveStartKey=scan["LastEvaluatedKey"])
        with table.batch_writer() as batch:
            for item in scan.get("Items", []):
                batch.delete_item(Key={primary_key: item[primary_key]})


def create_product(name, description, category, price):
    resp = httpx.post(
        f"{PRODUCT_SERVICE_URL}/products",
        json={"name": name, "description": description,
              "category": category, "price": price},
        timeout=5.0,
    )
    resp.raise_for_status()
    data = resp.json()
    print(f"  Created product: {name} -> {data['product_id']}")
    return data["product_id"]


def add_inventory(product_id, stock):
    resp = httpx.post(
        f"{INVENTORY_SERVICE_URL}/inventory",
        json={"product_id": product_id, "stock": stock},
        timeout=5.0,
    )
    resp.raise_for_status()
    data = resp.json()
    print(f"  Added inventory: {product_id} stock={stock} -> {data}")


if __name__ == "__main__":
    print("Clearing Products_ecom table...")
    delete_all_items(products_table, "product_id")
    print("Clearing inventory_ecom table...")
    delete_all_items(inventory_table, "product_id")
    print("Done clearing.")

    products = [
        ("Wireless Headphones", "Noise-cancelling Bluetooth headphones",
         "Electronics", 89.99),
        ("Running Shoes", "Lightweight running shoes with arch support",
         "Sports", 129.99),
        ("Coffee Maker", "12-cup programmable coffee machine",
         "Home & Kitchen", 49.99),
        ("Backpack", "Waterproof 40L hiking backpack",
         "Outdoors", 79.99),
        ("Desk Lamp", "LED desk lamp with adjustable brightness",
         "Office", 34.99),
    ]

    print("\nCreating 5 products via Product Service...")
    product_ids = []
    for name, desc, cat, price in products:
        pid = create_product(name, desc, cat, price)
        product_ids.append(pid)

    print("\nAdding inventory for each product via Inventory Service...")
    stocks = [50, 30, 20, 15, 40]
    for pid, stock in zip(product_ids, stocks):
        add_inventory(pid, stock)

    print("\nDone! 5 products and inventory records created.")
