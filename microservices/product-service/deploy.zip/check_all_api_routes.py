import boto3

session = boto3.Session(profile_name="idp-sbx-trn-lab-01")
apg = session.client("apigatewayv2", region_name="ap-southeast-1")

api_ids = {
    "order": "uuz930mrx2",
    "cart": "55akltsjy7",
    "inventory": "g9c3k1vwe7",
    "payment": "f9ltky86oc"
}

for name, api_id in api_ids.items():
    print(f"\n=== Routes for {name} ({api_id}) ===")
    try:
        routes = apg.get_routes(ApiId=api_id).get("Items", [])
        for r in routes:
            print(f"  Route: {r.get('RouteKey')} | Auth: {r.get('AuthorizationType')}")
    except Exception as e:
        print(f"  Error: {e}")
