import os
import time
import secrets
import hashlib
import json
import boto3
from decimal import Decimal
from logger import get_logger

logger = get_logger(__name__)
JWT_SECRET = os.environ.get("JWT_SECRET", "IS2XRMkqOowrmCpBFhs4DAcJ0vul95G1WaH6gViK")

class LocalUserDB:
    def __init__(self, filename="db_users.json"):
        self.filename = filename
        if not os.path.exists(self.filename):
            with open(self.filename, "w") as f:
                json.dump({}, f)

    def _read(self):
        try:
            with open(self.filename, "r") as f:
                return json.load(f)
        except Exception:
            return {}

    def _write(self, data):
        try:
            with open(self.filename, "w") as f:
                json.dump(data, f, indent=4)
        except Exception as e:
            logger.error("LocalDB | Failed to write: %s", e)

    def put_item(self, Item):
        data = self._read()
        email = Item["email"]
        data[email] = Item
        self._write(data)
        logger.info(f"LocalDB | Saved user: {email}")

    def get_item(self, Key):
        data = self._read()
        email = Key["email"]
        item = data.get(email)
        if item:
            return {"Item": item}
        return {}

    def update_item(self, Key, UpdateExpression, ExpressionAttributeNames, ExpressionAttributeValues):
        data = self._read()
        email = Key["email"]
        if email not in data:
            return
        
        status_val = ExpressionAttributeValues.get(":s")
        if status_val:
            data[email]["status"] = status_val
        
        self._write(data)
        logger.info(f"LocalDB | Updated user status: {email} -> {status_val}")


_db_client = None
_use_local = False

def get_db():
    global _db_client, _use_local
    if _db_client is not None:
        return _db_client

    if _use_local:
        _db_client = LocalUserDB()
        return _db_client

    try:
        if os.environ.get("AWS_LAMBDA_FUNCTION_NAME"):
            resource = boto3.resource("dynamodb", region_name="ap-southeast-1")
        else:
            session = boto3.Session(profile_name="idp-sbx-trn-lab-01")
            resource = session.resource("dynamodb", region_name="ap-southeast-1")
        
        table = resource.Table("ecom-users")
        table.table_status
        _db_client = table
        logger.info("DynamoDB | Connected to AWS table: ecom-users")
    except Exception as e:
        logger.warning("DynamoDB | Connection failed for ecom-users: %s. Falling back to local file-based database.", e)
        _use_local = True
        _db_client = LocalUserDB()
    
    return _db_client

def base64url_encode(data: bytes) -> str:
    import base64
    return base64.urlsafe_b64encode(data).rstrip(b'=').decode('utf-8')

def sign_jwt(payload: dict) -> str:
    import json
    import hmac
    header = {"alg": "HS256", "typ": "JWT"}
    header_enc = base64url_encode(json.dumps(header).encode('utf-8'))
    payload_enc = base64url_encode(json.dumps(payload).encode('utf-8'))
    signing_input = f"{header_enc}.{payload_enc}".encode('utf-8')
    signature = hmac.new(JWT_SECRET.encode('utf-8'), signing_input, hashlib.sha256).digest()
    sig_enc = base64url_encode(signature)
    return f"{header_enc}.{payload_enc}.{sig_enc}"

def hash_password(password: str, salt: str = None) -> tuple[str, str]:
    if not salt:
        salt = secrets.token_hex(16)
    hashed = hashlib.sha256((password + salt).encode('utf-8')).hexdigest()
    return hashed, salt

def register_user(name: str, email: str, password_raw: str) -> dict:
    from fastapi import HTTPException
    import re
    if len(password_raw) < 8:
        raise HTTPException(status_code=400, detail="Password must be at least 8 characters long")
    if not re.search(r'[A-Z]', password_raw):
        raise HTTPException(status_code=400, detail="Password must contain at least one uppercase letter")
    if not re.search(r'[a-z]', password_raw):
        raise HTTPException(status_code=400, detail="Password must contain at least one lowercase letter")
    if not re.search(r'[0-9]', password_raw):
        raise HTTPException(status_code=400, detail="Password must contain at least one number")
    if not re.search(r'[!@#$%^&*(),.?\":{}|<>]', password_raw):
        raise HTTPException(status_code=400, detail="Password must contain at least one special character (!@#$%^&* etc.)")

    db = get_db()
    existing = db.get_item(Key={"email": email})
    if "Item" in existing:
        raise HTTPException(status_code=400, detail="User with this email already exists")

    code = str(secrets.randbelow(900000) + 100000) # 6 digit code
    expires_at = int(time.time()) + 600 # 10 minutes from now
    password_hash, salt = hash_password(password_raw)

    user_item = {
        "email": email,
        "name": name,
        "password_hash": password_hash,
        "salt": salt,
        "status": "VERIFICATION_PENDING",
        "verification_code": code,
        "code_expires_at": expires_at
    }

    db.put_item(Item=user_item)
    
    logger.info("=" * 60)
    logger.info(f"EMAIL MOCK SENT TO: {email}")
    logger.info(f"Verification Code: {code}")
    logger.info("=" * 60)

    return {
        "message": "User registered. Please check email/console for the verification code.",
        "email": email,
        "verification_code": code
    }

def verify_code(email: str, code: str) -> dict:
    from fastapi import HTTPException
    db = get_db()
    existing = db.get_item(Key={"email": email})
    if "Item" not in existing:
        raise HTTPException(status_code=400, detail="Invalid verification code")
    
    user = existing["Item"]
    if user.get("verification_code") != code or int(user.get("code_expires_at", 0)) < time.time():
        raise HTTPException(status_code=400, detail="Invalid verification code")

    db.update_item(
        Key={"email": email},
        UpdateExpression="SET #s = :s",
        ExpressionAttributeNames={"#s": "status"},
        ExpressionAttributeValues={":s": "VERIFIED"}
    )

    token = sign_jwt({"username": email, "email": email, "role": "user", "exp": int(time.time()) + 86400})
    return {
        "message": "Account verified successfully",
        "token": token,
        "username": email,
        "name": user.get("name", "")
    }

def login_user(email: str, password_raw: str) -> dict:
    from fastapi import HTTPException
    db = get_db()
    existing = db.get_item(Key={"email": email})
    if "Item" not in existing:
        raise HTTPException(status_code=400, detail="Invalid email or password")

    user = existing["Item"]
    password_hash, _ = hash_password(password_raw, user.get("salt"))
    if user.get("password_hash") != password_hash:
        raise HTTPException(status_code=400, detail="Invalid email or password")

    if user.get("status") != "VERIFIED":
        raise HTTPException(status_code=400, detail="User is not verified")

    # Determine role (if username contains admin or is specific admin email, set role to admin)
    role = "admin" if (email in ("admin", "admin@gmail.com", "madhumithamalu6@gmail.com") or "admin" in email.lower()) else "user"

    token = sign_jwt({"username": email, "email": email, "role": role, "exp": int(time.time()) + 86400})
    return {
        "message": "Login successful",
        "token": token,
        "username": email,
        "name": user.get("name", "")
    }

def get_all_users() -> list[dict]:
    db = get_db()
    users = []
    if type(db).__name__ == "LocalUserDB":
        data = db._read()
        for email, info in data.items():
            users.append({
                "name": info.get("name"),
                "email": email,
                "status": info.get("status"),
                "code_expires_at": info.get("code_expires_at")
            })
    else:
        try:
            response = db.scan()
            items = response.get("Items", [])
            for item in items:
                users.append({
                    "name": item.get("name", "N/A"),
                    "email": item.get("email"),
                    "status": item.get("status", "UNVERIFIED"),
                    "code_expires_at": int(item.get("code_expires_at", 0))
                })
        except Exception as e:
            logger.error("DB | Failed to scan user table: %s", e)
    return users
