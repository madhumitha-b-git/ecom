import unittest
from unittest.mock import MagicMock, patch
from fastapi.testclient import TestClient

# Mock the database get_table to prevent boto3 connection at import time
with patch("database.get_table") as mock_get_table:
    from main import app
    client = TestClient(app)


class TestProductService(unittest.TestCase):
    def test_health(self):
        response = client.get("/")
        self.assertEqual(response.status_code, 200)
        self.assertEqual(response.json(), {"service": "product-service", "status": "ok"})

    @patch("service.get_table")
    def test_get_products(self, mock_get_table):
        mock_table = MagicMock()
        mock_table.scan.return_value = {
            "Items": [
                {"product_id": "prod-1", "name": "Cast Iron Skillet", "price": 39.99, "category": "Utensils"}
            ]
        }
        mock_get_table.return_value = mock_table

        response = client.get("/v1/products")
        self.assertEqual(response.status_code, 200)
        self.assertEqual(len(response.json()), 1)
        self.assertEqual(response.json()[0]["name"], "Cast Iron Skillet")
        self.assertEqual(response.json()[0]["price"], 39.99)

    @patch("service.get_table")
    def test_get_product_by_id_success(self, mock_get_table):
        mock_table = MagicMock()
        mock_table.get_item.return_value = {
            "Item": {"product_id": "prod-1", "name": "Cast Iron Skillet", "price": 39.99, "category": "Utensils"}
        }
        mock_get_table.return_value = mock_table

        response = client.get("/v1/products/prod-1")
        self.assertEqual(response.status_code, 200)
        self.assertEqual(response.json()["name"], "Cast Iron Skillet")

    @patch("service.get_table")
    def test_get_product_not_found(self, mock_get_table):
        mock_table = MagicMock()
        mock_table.get_item.return_value = {}  # Empty response simulates not found
        mock_get_table.return_value = mock_table

        response = client.get("/v1/products/invalid-id")
        self.assertEqual(response.status_code, 404)
        self.assertTrue("not found" in response.json()["detail"].lower())


if __name__ == "__main__":
    unittest.main()
