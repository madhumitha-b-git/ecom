import boto3

session = boto3.Session(profile_name="idp-sbx-trn-lab-01")
apg = session.client("apigatewayv2", region_name="ap-southeast-1")

api_ids = ["uuz930mrx2", "f9ltky86oc", "g9c3k1vwe7", "55akltsjy7"]

for api_id in api_ids:
    try:
        api = apg.get_api(ApiId=api_id)
        print(f"API: {api_id} -> EXISTS (Name: {api.get('Name')})")
    except Exception as e:
        print(f"API: {api_id} -> NOT FOUND ({e})")
