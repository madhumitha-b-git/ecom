import unittest
from unittest.mock import MagicMock, patch
from fastapi.testclient import TestClient

# Mock database at import time to prevent network attempts
with patch("database.get_table") as mock_get_table:
    from main import app
    client = TestClient(app)


class TestPaymentService(unittest.TestCase):
    def test_health(self):
        response = client.get("/")
        self.assertEqual(response.status_code, 200)
        self.assertEqual(response.json(), {"service": "payment-service", "status": "ok"})

    @patch("service.get_table")
    def test_create_payment(self, mock_get_table):
        mock_table = MagicMock()
        mock_get_table.return_value = mock_table

        token = "dXNlcjEyMzoxNzIwMDAwMDAw"
        response = client.post(
            "/v1/payments",
            headers={"Authorization": f"Bearer {token}"},
            json={"order_id": "order-123", "amount": 99.99}
        )
        self.assertEqual(response.status_code, 201)
        self.assertIn("payment_id", response.json())
        self.assertEqual(response.json()["status"], "SUCCESS")


if __name__ == "__main__":
    unittest.main()
